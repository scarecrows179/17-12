package ru.akhtyamov.akhtyamov2_task1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SumContorller {

    @FXML
    private Label LMetr;

    @FXML
    private TextField LText;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        double L=Double.parseDouble(LText.getText().toString());
        LMetr.setText("L(metr)="+(L/100));

    }

}
