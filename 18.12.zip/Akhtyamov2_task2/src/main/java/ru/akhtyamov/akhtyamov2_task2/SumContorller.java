package ru.akhtyamov.akhtyamov2_task2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SumContorller {

    @FXML
    private Label Res;

    @FXML
    private TextField num;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        float a=Float.parseFloat(num.getText().toString());
        double b;
        double c;
        b=a%10;
        c=a/10;
        Res.setText("Num="+(int)(b*100+c));

    }

}
