module ru.akhtyamov.akhtyamov2_task2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.akhtyamov.akhtyamov2_task2 to javafx.fxml;
    exports ru.akhtyamov.akhtyamov2_task2;
}