package ru.akhtyamov.akhtyamov2_task3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SumContorller {

    @FXML
    private Label Day;

    @FXML
    private TextField num;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        float K=Float.parseFloat(num.getText().toString());
        int b=(int)(K%7+1)%7;
        switch (b){
            case 1:
                Day.setText("Воскресенье");
                break;
            case 2:
                Day.setText("Понедельник");
                break;
            case 3:
                Day.setText("Вторник");
                break;
            case 4:
                Day.setText("Среда");
                break;
            case 5:
                Day.setText("Четверг");
                break;
            case 6:
                Day.setText("Пятница");
                break;
            case 0:
                Day.setText("Суббота");
                break;
        }

    }

}
