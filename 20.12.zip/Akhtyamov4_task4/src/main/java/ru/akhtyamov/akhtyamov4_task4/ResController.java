package ru.akhtyamov.akhtyamov4_task4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ResController {

    @FXML
    private TextField AT;

    @FXML
    private TextField BT;

    @FXML
    private Label RL;

    @FXML
    void btn(ActionEvent event) {
        float a=Float.parseFloat(AT.getText().toString());
        float b=Float.parseFloat(BT.getText().toString());
        while(a>b){
            a-=b;
        }
        RL.setText("Длина части"+a);


    }

}
