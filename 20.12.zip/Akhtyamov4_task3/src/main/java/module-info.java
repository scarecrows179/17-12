module ru.akhtyamov.akhtyamov4_task3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.akhtyamov.akhtyamov4_task3 to javafx.fxml;
    exports ru.akhtyamov.akhtyamov4_task3;
}