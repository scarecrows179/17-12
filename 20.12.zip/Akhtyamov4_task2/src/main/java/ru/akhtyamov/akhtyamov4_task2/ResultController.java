package ru.akhtyamov.akhtyamov4_task2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ResultController {

    @FXML
    private Label card;

    @FXML
    private TextField mT;

    @FXML
    private TextField nT;

    @FXML
    void btn(ActionEvent event) {
        int m=Integer.parseInt(mT.getText().toString());
        int n=Integer.parseInt(nT.getText().toString());
        String a="";
        String b="";
        switch (n){
            case 6:
                a="шестёрка";
                break;
            case 7:
                a="семёрка";
                break;
            case 8:
                a="восьмёрка";
                break;
            case 9:
                a="девятка";
                break;
            case 10:
                a="десятка";
                break;
            case 11:
                a="валет";
                break;
            case 12:
                a="дама";
                break;
            case 13:
                a="король";
                break;
            case 14:
                a="туз";
                break;
        }
        switch (m) {
            case 1:
                b = "пики";
                break;
            case 2:
                b = "терфы";
                break;
            case 3:
                b = "бубны";
                break;
            case 4:
                b = "черьви";
                break;
        }
        card.setText("Карта:"+a+" "+b);



        }
    }


