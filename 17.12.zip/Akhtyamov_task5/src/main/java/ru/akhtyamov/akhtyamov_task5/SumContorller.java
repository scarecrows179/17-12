package ru.akhtyamov.akhtyamov_task5;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import static java.lang.Math.*;

public class SumContorller {

    @FXML
    private TextField A1TextField;

    @FXML
    private TextField A2TextField;

    @FXML
    private TextField B1TextField;

    @FXML
    private TextField B2TextField;

    @FXML
    private TextField C1TextField;

    @FXML
    private TextField C2TextField;

    @FXML
    private Label DLabel;

    @FXML
    private Label H1Label;

    @FXML
    private Label H2Label;

    @FXML
    private Label xLabel;

    @FXML
    private Label yLabel;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        float A1=Float.parseFloat(A1TextField.getText().toString());
        float B1=Float.parseFloat(B1TextField.getText().toString());
        float C1=Float.parseFloat(C1TextField.getText().toString());
        float A2=Float.parseFloat(A2TextField.getText().toString());
        float B2=Float.parseFloat(B2TextField.getText().toString());
        float C2=Float.parseFloat(C2TextField.getText().toString());
        float D=A1*B2 - A2*B1;
        float y=(A1*C2 - A2*C1)/D;
        float x=(C1*B2 - C2*B1)/D;
        DLabel.setText("D="+ (A1*B2 - A2*B1));
        yLabel.setText("y="+ ((A1*C2 - A2*C1)/D));
        xLabel.setText("x="+ ((C1*B2 - C2*B1)/D));
        H1Label.setText("H1="+ (A1*x + B1*y));
        H2Label.setText("H2="+ (A2*x + B2*y));



    }
}
