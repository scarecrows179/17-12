module ru.akhtyamov.akhtyamov_task5 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.akhtyamov.akhtyamov_task5 to javafx.fxml;
    exports ru.akhtyamov.akhtyamov_task5;
}