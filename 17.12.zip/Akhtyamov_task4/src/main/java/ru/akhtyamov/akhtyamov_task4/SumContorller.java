package ru.akhtyamov.akhtyamov_task4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import static java.lang.Math.*;

public class SumContorller {

    @FXML
    private Label YLabel;

    @FXML
    private TextField aTextField;

    @FXML
    private TextField bTextField;

    @FXML
    private TextField xTextField;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        float A=Float.parseFloat(aTextField.getText().toString());
        float B=Float.parseFloat(bTextField.getText().toString());
        float X=Float.parseFloat(xTextField.getText().toString());
        float y= (float) (-pow(A,5)*X + B* pow(cos(pow(X,2)),4)+B*X);
        YLabel.setText("Y="+ sqrt(abs(-A*X+y))/ (log(abs(X+ pow(y,2)))));


    }

}
