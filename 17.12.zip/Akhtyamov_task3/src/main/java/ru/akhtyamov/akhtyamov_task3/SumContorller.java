package ru.akhtyamov.akhtyamov_task3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SumContorller {

    @FXML
    private Label DLabel;

    @FXML
    private Label X1Label;

    @FXML
    private Label X2Label;

    @FXML
    private TextField aTextField;

    @FXML
    private TextField bTextField;

    @FXML
    private TextField cTextField;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        float a=Float.parseFloat(aTextField.getText().toString());
        float b=Float.parseFloat(bTextField.getText().toString());
        float c=Float.parseFloat(cTextField.getText().toString());
        float D= (float) (Math.pow(b,2) - 4 * a * c);
        DLabel.setText("Дискрименант="+ (Math.pow(b,2) - 4 * a * c));
        X1Label.setText("Корень 1="+ ((-b + Math.sqrt(D))/(2 * a)));
        X2Label.setText("Корень 2="+ ((-b - Math.sqrt(D))/(2 * a)));
    }

}
