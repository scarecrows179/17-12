﻿package ru.akhtyamov.akhtyamov_task2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class SumController {

    @FXML
    private TextField LTextField;

    @FXML
    private Label rLabel;

    @FXML
    private Label sLabel;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        float L=Float.parseFloat(LTextField.getText().toString());
        float pi=3.14f;
        float r=L/6.28f;
        rLabel.setText("Радиус="+ (L/6.28f));
        sLabel.setText("Площадь="+ (pi*(r*r)));

    }

}
