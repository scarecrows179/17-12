package ru.akhtyamov.akhtyamov3_task5;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class ResController {

    @FXML
    private ImageView qwe;

    @FXML
    private TextField xt;

    @FXML
    private TextField yt;

    @FXML
    private Label zxc;

    @FXML
    void btn(ActionEvent event) {
        float x = Float.parseFloat(xt.getText().toString());
        float y = Float.parseFloat(yt.getText().toString());
        Image image = new Image(getClass().getResourceAsStream("/Screenshot_83.jpg"));
        qwe.setImage(image);

        if (x <= 0 && y >= 0 && y <= 23 && y >= -x) {
            if (y == 23 || y == -x || x == 0 || y == 0) {
                zxc.setText("На границе");
            } else {
                zxc.setText("Да");
            }
        } else {
            zxc.setText("Нет");

        }

    }
}
