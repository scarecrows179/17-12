package ru.akhtyamov.akhtyamov3_task4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import static java.lang.Math.*;

public class ResultController {

    @FXML
    private TextField AT;

    @FXML
    private Label zxc;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        int a=Integer.parseInt(AT.getText().toString());
        double y;
        if(a<0) {
            y= pow(a,2)-3 - cbrt(PI-a);
        }else if(a>=0&&a<-1){
            y=pow(pow(a,2)+3,2)-sqrt(0.5*PI+a);
        }else{
            y=a*(pow(a,2+3)+log(PI+a));
        }
        zxc.setText(String.format("Y=%.2f",y));

    }

}
