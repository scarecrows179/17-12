module ru.akhtyamov.akhtyamov3_task4 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.akhtyamov.akhtyamov3_task4 to javafx.fxml;
    exports ru.akhtyamov.akhtyamov3_task4;
}