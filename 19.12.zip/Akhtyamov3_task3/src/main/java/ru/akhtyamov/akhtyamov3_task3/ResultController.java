package ru.akhtyamov.akhtyamov3_task3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ResultController {

    @FXML
    private TextField AT;

    @FXML
    private TextField BT;

    @FXML
    private TextField CT;

    @FXML
    private TextField DT;

    @FXML
    private Label zxc;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        int a = Integer.parseInt(AT.getText().toString());
        int b = Integer.parseInt(BT.getText().toString());
        int c = Integer.parseInt(CT.getText().toString());
        int d = Integer.parseInt(DT.getText().toString());
        int v;
        if (a != b && a != c && a != d) {
            v = 1;
        } else if (b != a && b != c && b != d) {
            v = 2;
        } else if (c != a && c != b && c != d) {
            v = 3;
        } else {
            v = 4;
        }
        zxc.setText("Порядковый номер числа:" + v);

    }

}
