package ru.akhtyamov.akhtyamov3_task1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ResultController {

    @FXML
    private Label ResultLabel;

    @FXML
    private TextField mTextField;

    @FXML
    private TextField nTextField;

    @FXML
    void sumButtonOnAction(ActionEvent event) {
        int m = Integer.parseInt(mTextField.getText().toString());
        int n = Integer.parseInt(nTextField.getText().toString());
        if (n != 0) {
            if (m % n == 0) {
                ResultLabel.setText("Частное от деления:" + (m / n));
            } else {
                ResultLabel.setText("m на n нацело не делится");
            }
        }
    }
}

