package ru.akhtyamov.akhtyamov5_task3;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class ResController {

    @FXML
    private TextField aT;

    @FXML
    private TextField bT;

    @FXML
    private Label rL;

    @FXML
    void ab(ActionEvent event) {

    }

}
