module ru.akhtyamov.akhtyamov5_task2 {
    requires javafx.controls;
    requires javafx.fxml;


    opens ru.akhtyamov.akhtyamov5_task2 to javafx.fxml;
    exports ru.akhtyamov.akhtyamov5_task2;
}